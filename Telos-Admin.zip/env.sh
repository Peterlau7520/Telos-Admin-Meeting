export MONGODB_URI="mongodb://admin:admin@ds117625.mlab.com:17625/telos"
export S3_KEY="AKIAIMLMZLII2XCKU6UA"
export secretAccessKey="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"
