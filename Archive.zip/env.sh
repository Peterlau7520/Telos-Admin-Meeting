export MONGODB_URI="mongodb://admin:admin@ds117625.mlab.com:17625/telos"
#Mongodb atlas uri: mongodb://admin:admin@cluster0-shard-00-00-c9uem.mongodb.net:27017,cluster0-shard-00-01-c9uem.mongodb.net:27017,cluster0-shard-00-02-c9uem.mongodb.net:27017/Telos?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin
#Mongodb mlab uri: mongodb://admin:admin@ds117625.mlab.com:17625/telos
export S3_KEY="AKIAIMLMZLII2XCKU6UA"
export secretAccessKey="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"
